﻿using System;
using System.Collections.Generic;
using OnlineStoreManagementSystem.Models;
using OnlineStoreManagementSystem.Services.Discounts;
using OnlineStoreManagementSystem.Services.Payments;

namespace OnlineStoreManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create store owner and subscribe to out-of-stock event
            StoreOwner owner = new StoreOwner();
            Order.OutOfStockEvent += owner.OnProductOutOfStock;

            // Create products
            PhysicalProduct laptop = new PhysicalProduct("Laptop", 1000m, 10);
            DigitalProduct eBook = new DigitalProduct("E-Book", 20m, 100);

            // Create customer
            Customer customer = new Customer("John", "Doe");

            // Create discount
            IDiscount discount = new PercentageDiscount(10); // 10% discount

            // Choose payment method
            IPayment paymentMethod = new CreditCardPayment();

            // Place an order
            List<Product> products = new List<Product> { laptop, eBook };
            Order order = new Order(customer, products, 2, discount, paymentMethod);
            order.ProcessOrder();

            // Test stock depletion for laptop
            Order anotherOrder = new Order(customer, new List<Product> { laptop }, 10, discount, paymentMethod);
            anotherOrder.ProcessOrder();
        }
    }
}   